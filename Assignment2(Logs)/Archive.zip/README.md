Assignment 2 "Log analysis".
Nikita Baranov student ID 40012854
Github: https://github.com/NikitaBaranov/SOEN-691-Big-Data-W17/tree/master/Assignment2(Logs)

To run:
spark-submit log_lab_Nikita_Baranov.py -q <int number of question> <file1/dir1> <file2/dir2>

positional arguments:
  dir1        File or directory with logfiles
  dir2        File or directory with logfiles

optional arguments:
  -h, --help  show this help message and exit
  -q Q        Number of Question

Requirements:
	- python 2,7
	- Apache Spark 2.1
